# MY FAVORITE MOVIE NAMES AND TRAILER URLS

A Pen created on CodePen.io. Original URL: [https://codepen.io/vanefati/pen/XWOzVZM](https://codepen.io/vanefati/pen/XWOzVZM).

Pagina para  add  lista com nomes, imagens e trailers de filmes favoritos