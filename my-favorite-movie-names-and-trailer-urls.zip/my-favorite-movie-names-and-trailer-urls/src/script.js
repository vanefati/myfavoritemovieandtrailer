var listaFilmes = []
var listaTrailers = []
var listaNomes = []

function adicionarFilme() {
  var filme= document.getElementById('filme').value
  var trailer = document.getElementById('trailer').value
  var nome = document.getElementById('nome').value
  
  if (filme == '' || trailer == '' || nome == '') {
  alert('Preencha todos os campos')
  return 0; 
  }
 
  listaFilmes.push(filme)
  listaTrailers.push(trailer)
  listaNomes.push(nome)
  
  if (filme.endsWith('jpg') || filme.endsWith('png')) {
   var elementoListaFilmes = document.getElementById('listaFilmes')
    
    elementoListaFilmes.innerHTML = ''
    for (i in listaFilmes) {
      elementoListaFilmes.innerHTML += 
      "<div class='container_filme'>" + 
      "<img id= " + i +  " src= " + listaFilmes[i] + " onClick=assistirTrailer(this.id)>" + 
      "<p>" + listaNomes[i] + "</p>" +
      "</div>"
     
      document.getElementById('filme').value = ''
      document.getElementById('nome').value = ''
      document.getElementById('trailer').value = ''
    } 
  } 
}
  function assistirTrailer(id) {
  window.open(listaTrailers[id], "_blank");
}

  
  